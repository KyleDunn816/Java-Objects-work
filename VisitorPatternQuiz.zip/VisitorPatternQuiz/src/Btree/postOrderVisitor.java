package Btree;



public class postOrderVisitor implements IBTVisitor<String, String> {

	//concatenates the elements of a String BTree in post order
    

    public String leafnode(String val) {

        

        return val;

    }

    

    public String interiornode(String val, String l, String r) {

        

        return (l+" "+r+" "+val);

        

    }



}
