package Btree;

public interface IBTVisitor<X,R> {
	
	//accesses the elements of a leaf node and interior node
	
	public R leafnode(X val);
	public R interiornode(X val, R l, R r);

}
