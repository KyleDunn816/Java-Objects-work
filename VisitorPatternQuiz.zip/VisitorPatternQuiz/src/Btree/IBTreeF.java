package Btree;

public interface IBTreeF<X,Y> {
	
	public Y f(X v);
	

}
