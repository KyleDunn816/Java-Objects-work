package Btree;

public class maxTree implements IBTVisitor<Integer, Integer> {

	// finds the maximum value of a binary tree

    public Integer leafnode(Integer val) {

        

        return val;

    }

    

    public Integer interiornode(Integer val, Integer l, Integer r) {

        

        return Math.max(Math.max(val, l), r);

    }



}