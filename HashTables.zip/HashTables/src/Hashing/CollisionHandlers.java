package Hashing;

import java.util.ArrayList;
import java.util.Iterator;

import Dictionary.IDictionary;

public abstract class CollisionHandlers<K,E> implements IDictionary<K,E> {

	protected Item <K,E> AVAILABLE = new Item< K,E> (null,null); // deleted cell item
	protected int n; // number of elements in the hash table
	protected int N; // size of the array
	protected ArrayList<Item<K,E>> A;
	protected HashComparator<K> h; // provides hashIndex and Equals
	protected int Collisions = 0;

	protected abstract int find(K k);
	

	public CollisionHandlers(int s, HashComparator<K> hc) {

		n = 0;
		h = hc;
		N = s;
		int i = 0;
		A = new ArrayList <Item <K,E>>(s);
		
		while (i<=s-1) {

			A.add(i, null); 
			i = i+1;
		}

	}


	// auxiliary methods


	protected boolean available(int i) {

		return(A.get(i)==AVAILABLE);
	}

	protected boolean empty(int i) {

		return(A.get(i)==null);

	}


	public K key(int i) {

		return(A.get(i).getKey());
	}


	private E elem(int i) {

		return(A.get(i).getElem());
	}



	// Dictionary methods

	public Integer size() {

		return(n);
	}

	public Boolean isEmpty() {

		return (n==0);


	}

	public Iterator<E> elements() {

		Iterator<Item<K,E>> htlooper = A.iterator();
		ArrayList<E> elems = new ArrayList<E>();
		Item<K,E> k;
		while (htlooper.hasNext()) {

			k= htlooper.next();
			if ((k!= null) && (k!= AVAILABLE)) {

				elems.add(k.getElem());
			}
		}

		return(elems.iterator());
	}



	public Iterator<K> keys() {

		Iterator<Item<K,E>> htlooper = A.iterator();
		ArrayList<K> keys = new ArrayList<K> ();
		Item<K,E> k;
		while (htlooper.hasNext()) {

			k = htlooper.next();
			if ((k!=null) && (k!= AVAILABLE)) {

				keys.add(k.getKey());
			}

		}

		return(keys.iterator());

	}


	public E findElement(K k) {

		int i = find(k);
		if (i<0) {

			return(null);

		}

		else {

			return(elem(i));

		}
	}


	public void insert(K k, E e) {

		//Assumes this HT is not full

		int i = h.hashIndex(k) % N;
		int j = i;
		int s = i;
		boolean done = false;
		while (!done) {

			if (empty(j) || available(j)) {

				A.set(j, new Item<K,E> (k,e));
				n= n+1;
				done = true;
			}

			s = (s+1) % N;
		}
	}


	public void delete (K k) {

		int i = find(k);
		if (i>-1) {

			A.set(i, AVAILABLE);
			n=n-1;
		}

	}
}
