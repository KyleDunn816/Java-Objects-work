package Hashing;

import java.util.ArrayList;
import java.util.Random;

public class CompareCollisionHandlers {
	
	// There to compare the performance of LPHash and DoubleHashing
	// by assessing how many collisions occur while executing the functions
	
	
	// Generates a random string of integers
	public static String RandomStringGenerator() {
		
		String randomString = "";
		int i = 0;
		Random r = new Random();
		
		while (i<1+r.nextInt(20)) {
			
			randomString = randomString + (char) r.nextInt(256); // generates random characters in ASCII code
			i++;
		}
		
		return(randomString);
	}
	
	
	// Makes an array of strings and adds randomly generated strings to it
	public static ArrayList<String> makeList(int length) {
		
	    ArrayList<String> array = new ArrayList<String>(); 
		String str;
		int i = 0; 
		
		
		
		while(i < length) { 
			str = RandomStringGenerator(); 
			if(!array.contains(str)) { 
				array.add(str); 
				i++; 
			}
		}
		return array; 
		
	}
	
	// runs both of the collision handlers and prints the amount of collisions
	public static void main(String[] args) {
		int size = 1000;
		while(size <= 10000) {
			HashComparator<String> hc = new StringComparator();
			LPHash<String, String> LP = new LPHash<String, String>(10007, hc);
			//DoubleHashing<String, String> DB = new DoubleHashing<String, String>(10007, hc);
			ArrayList<String> keys = makeList(size);
			ArrayList<String> elems = makeList(size);
			for(int i = 0; i<keys.size(); i++)
			{
				//DB.insert(keys.get(i), elems.get(i));
				LP.insert(keys.get(i), elems.get(i));
			}
			
			//int DBcollisions = DB.Collisions;
			int LPcollisions = LP.Collisions;
			System.out.println("Collisions for array size " + size);
			//System.out.println(DBcollisions);
			System.out.println(LPcollisions);
			size = size + 1000;
		}
		

	}
	
	
	
	

}
