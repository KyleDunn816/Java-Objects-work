package Hashing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

import org.junit.jupiter.api.Test;

public class LPHashTest {
	
	

	@Test
	void testHT() {
		
		HashComparator<String> scomp = new StringComparator(); 
		LPHash<String, String> HashTable = new LPHash<String, String>(101, scomp); 
		
		assertEquals(HashTable.size(), 0); 
		assertEquals(HashTable.isEmpty(), true); 
		assertEquals(HashTable.findElement("Tijana"), null); 
		
		HashTable.insert("Best", "Coders");
		HashTable.insert("Joe", "Lakhman");
		HashTable.insert("Kyle", "Dunn");
		HashTable.insert("Best", "Coders");
		
		assertEquals(HashTable.size(), 4); 
		assertEquals(HashTable.isEmpty(), false);
		assertEquals(HashTable.findElement("Kyle"), "Dunn"); 
		assertEquals(HashTable.findElement("Marco"), null); 
		
		HashTable.delete("Best");
		assertEquals(HashTable.findElement("Best"), null);
		
		Iterator<String> klooper = HashTable.keys(); 
		Iterator<String> elooper = HashTable.elements();
		String res = ""; 
		while (klooper.hasNext()) { 
			res = res + " " + klooper.next() + " " + elooper.next();
		}
		assertEquals(res, " Kyle Dunn Tijana Minic Joe Lakhman"); 
	
	
	}

}
