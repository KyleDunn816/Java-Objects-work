package Hashing;

public class DoubleHashing<K,E> extends CollisionHandlers<K,E> {
	
	private int q = 13;

	public DoubleHashing(int s, HashComparator<K> hc) {
		super(s, hc);
	}
	
	//Purpose: to insert an element and key
	public void insert(K k, E e) {

		//Assumes this HT is not full

		int i = h.hashIndex(k) % N;
		int j = i;
		int dh = q-(j%q);
		boolean done = false;
		while (!done) {

			if (empty(j) || available(j)) {

				A.set(j, new Item<K,E> (k,e));
				n= n+1;
				done = true;
			}
			
			else {
				
				this.Collisions++;
				j = (j+dh) % N; // j becomes the second hash function
				
			}

	
		}
		
		
	}

	//Purpose: to find a key in a Table
	protected int find(K k) { 

		int i = (h.hashIndex(k)% N); // division method compression map
		int j = i; // hash function
		int res = -1;
		int dh = q-(j%q);
		boolean done = false; // indicates that the search is done

		while (!done) {

			if (empty(j)) {

				done = true;
			}

			else if (available(j)) {

				j = (j+1) % N;

				if (j==i) {

					done = true;
				}

			}

			else if (h.keyEqual(key(j),k)) { 
				res = j;
				done = true;
			}

			else {

				j = (j+dh) % N;

				if (j==i) { 

					done = true;
				}
			}
		}

		return(res);

	}
	
	



}
